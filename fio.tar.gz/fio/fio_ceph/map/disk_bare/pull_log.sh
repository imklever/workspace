#!/bin/bash

mkdir log_37
scp -r 10.240.220.37:/root/fio_test/log/* ./log_37
