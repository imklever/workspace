#!/bin/bash

yum install -y vim fio bc time hdparm
