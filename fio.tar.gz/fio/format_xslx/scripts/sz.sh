#!/bin/bash

sz ./xlsx/*
