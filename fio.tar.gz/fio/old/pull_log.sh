#!/bin/bash

scp -r 10.240.220.38:/root/fio_test/log/* ./log_38
scp -r 10.240.220.39:/root/fio_test/log/* ./log_39
